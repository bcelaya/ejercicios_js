/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function sumardiez(){
	var valor = document.getElementById("valor").value;
	valor = parseInt(valor);
	valor = valor + 10;
	document.getElementById("valor").value = valor;
	}

function reestablecercont(){
	valor = 0;
	document.getElementById("valor").value = valor;
}
