/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function compruebadni(){
	var textodni = document.getElementsByName("dni")[0].value;
	if((textodni.length)===0){
	alert("No ha introducido su DNI, por favor introduzcalo");
	}
}

